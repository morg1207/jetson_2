# Palet-Detection > 2023-08-02 1:03pm
https://universe.roboflow.com/combuster/palet-detection-hvh3n

Provided by a Roboflow user
License: CC BY 4.0

